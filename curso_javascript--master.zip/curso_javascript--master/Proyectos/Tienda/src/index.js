import Tabs from './tabs';
import './producto';
import './carrito';

// Creamos una instancia de Tabs
new Tabs('mas-informacion');
