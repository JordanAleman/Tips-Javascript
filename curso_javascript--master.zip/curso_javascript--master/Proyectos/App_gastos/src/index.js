import './eventosGasto';
import './eventoBtnFormularioGasto';
import './agregarGasto';
import cargarGastos from './cargarGastos';
import cargarTotalGastado from './cargarTotalGastado';

cargarGastos();
cargarTotalGastado();
