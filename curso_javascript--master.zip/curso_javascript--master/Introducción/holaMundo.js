alert('Hola mundo, desde archivo externo');
