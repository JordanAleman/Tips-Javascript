console.log('Soy codigo que se ejecuta desde el archivo emptyExport.js');

export const correo = 'correo@correo.com';
